# 🚀 Quick Start Guide

Follow these steps to get your Expense Manager running:

## 1️⃣ Install PostgreSQL
- Download from: https://www.postgresql.org/download/
- Install and remember your password

## 2️⃣ Create Database
Open PostgreSQL and run:
```sql
CREATE DATABASE expense_manager;
```

## 3️⃣ Run Database Script
In PostgreSQL, run the `database.sql` file to create the table.

## 4️⃣ Install Node.js Packages
```bash
npm install
```

## 5️⃣ Create .env File
Create a file named `.env` in the project folder with:
```
DB_USER=postgres
DB_HOST=localhost
DB_NAME=expense_manager
DB_PASSWORD=your_password_here
DB_PORT=5432
PORT=3000
```
**Replace `your_password_here` with your PostgreSQL password!**

## 6️⃣ Start Backend
```bash
npm start
```

## 7️⃣ Open Frontend
Open `index.html` in your browser!

---

## ✅ That's it! Your app is ready!

If you see errors, check:
- PostgreSQL is running
- Database exists
- .env file has correct password
- Port 3000 is available

