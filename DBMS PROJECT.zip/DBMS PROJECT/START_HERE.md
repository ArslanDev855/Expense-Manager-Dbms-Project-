# 🚀 START HERE - Quick Setup Guide

## Follow These 8 Steps:

### ✅ Step 1: Check PostgreSQL is Installed
- [ ] PostgreSQL installed? If not: https://www.postgresql.org/download/
- [ ] Remember your PostgreSQL password!

---

### ✅ Step 2: Create Database
**Open pgAdmin** → Right-click "Databases" → Create → Database
- Name: `expense_manager`
- Click Save

**OR use command:**
```bash
psql -U postgres
CREATE DATABASE expense_manager;
\q
```

---

### ✅ Step 3: Create Table
**In pgAdmin:**
- Right-click `expense_manager` → Query Tool
- Copy contents of `database.sql` → Paste → Execute

**OR use command:**
```bash
psql -U postgres -d expense_manager -f database.sql
```

---

### ✅ Step 4: Edit .env File
1. Open `.env` file in this folder
2. Change `DB_PASSWORD=postgres` to your actual PostgreSQL password
3. Save the file

**Example:**
```
DB_PASSWORD=your_actual_password_here
```

---

### ✅ Step 5: Install Packages
**Open PowerShell in this folder, run:**
```bash
npm install
```

---

### ✅ Step 6: Start Backend
**In PowerShell, run:**
```bash
npm start
```

**You should see:**
```
✅ Connected to PostgreSQL database
✅ Database table initialized
🚀 Server running on http://localhost:3000
```

**KEEP THIS WINDOW OPEN!**

---

### ✅ Step 7: Test Connection
**Open browser, go to:**
```
http://localhost:3000/api/health
```

**Should show:** `{"status":"OK","database":"Connected"}`

---

### ✅ Step 8: Open Frontend
**Double-click `index.html`** or open in browser

**Done! 🎉**

---

## 🆘 Having Problems?

**Backend won't start?**
- Check `.env` file has correct password
- Make sure PostgreSQL is running

**Database error?**
- Check database `expense_manager` exists
- Check password in `.env` is correct

**Frontend can't connect?**
- Make sure backend is running (Step 6)
- Check browser console (F12) for errors

---

**For detailed steps, see: `BACKEND_SETUP_STEPS.md`**

