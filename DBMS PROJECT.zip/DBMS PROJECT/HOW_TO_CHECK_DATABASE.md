# 🔍 How to Check if Data is Saved in PostgreSQL

## Method 1: Using pgAdmin (Easiest - GUI) ⭐

### Step 1: Open pgAdmin
- Search for "pgAdmin" in Windows Start menu
- Open it

### Step 2: Connect to Database
1. Expand **"Servers"** → **"PostgreSQL"**
2. Enter your password if asked
3. Expand **"Databases"** → **"expense_manager"**
4. Expand **"Schemas"** → **"public"** → **"Tables"**

### Step 3: View Data
1. Right-click on **"expenses"** table
2. Click **"View/Edit Data"** → **"All Rows"**
3. **You should see all your expenses!** ✅

**Or use Query Tool:**
1. Right-click **"expense_manager"** database
2. Click **"Query Tool"**
3. Type this query:
```sql
SELECT * FROM expenses;
```
4. Click **"Execute"** (or press F5)
5. See all your data! ✅

---

## Method 2: Using Command Line (psql)

### Step 1: Open PowerShell
- Press `Win + X` → Windows PowerShell

### Step 2: Connect to PostgreSQL
```bash
psql -U postgres -d expense_manager
```
- Enter your password when asked

### Step 3: View All Data
```sql
SELECT * FROM expenses;
```

### Step 4: See Formatted Results
```sql
SELECT * FROM expenses ORDER BY created_at DESC;
```

### Step 5: Count Records
```sql
SELECT COUNT(*) FROM expenses;
```

### Step 6: Exit
```sql
\q
```

---

## Method 3: Using API Endpoint (Quick Check)

### In Browser:
1. Open: `http://localhost:3000/api/expenses`
2. You should see JSON data with all expenses
3. If you see `[]` - no data yet
4. If you see data - it's saved! ✅

**Example response:**
```json
[
  {
    "id": 1,
    "description": "Groceries",
    "amount": "1500.00",
    "category": "Food",
    "date": "2024-01-15",
    "created_at": "2024-01-15T10:30:00.000Z"
  }
]
```

---

## Method 4: Check in Frontend

1. Add an expense in your frontend
2. It should appear in the "Expense History" section
3. If it appears there, it's saved in database! ✅

---

## 🔍 Detailed Queries to Check Data

### View All Expenses:
```sql
SELECT * FROM expenses;
```

### View Expenses with Total:
```sql
SELECT 
    id,
    description,
    amount,
    category,
    date,
    created_at
FROM expenses
ORDER BY date DESC;
```

### Count Total Expenses:
```sql
SELECT COUNT(*) as total_expenses FROM expenses;
```

### Sum of All Amounts:
```sql
SELECT SUM(amount) as total_amount FROM expenses;
```

### View by Category:
```sql
SELECT category, COUNT(*) as count, SUM(amount) as total
FROM expenses
GROUP BY category;
```

### View Recent Expenses:
```sql
SELECT * FROM expenses 
ORDER BY created_at DESC 
LIMIT 10;
```

---

## ✅ Quick Test: Add Data and Verify

### Step 1: Add Expense in Frontend
- Fill form and click "Add Expense"

### Step 2: Check Database (Choose one method above)

### Step 3: Verify
- ✅ Data appears in database = Working!
- ❌ No data = Check backend errors

---

## 🐛 Troubleshooting

### No Data Showing?
1. **Check backend is running** - Terminal should show server running
2. **Check backend terminal** - Look for any error messages
3. **Check browser console** - Press F12 → Console tab → Look for errors
4. **Verify database connection** - Go to `http://localhost:3000/api/health`

### Data Not Saving?
1. Check backend terminal for errors
2. Check `.env` file has correct database password
3. Verify PostgreSQL is running
4. Check browser console (F12) for API errors

### Can't Connect to Database?
1. Make sure PostgreSQL service is running
2. Check database name is `expense_manager`
3. Verify password in `.env` file is correct

---

## 📊 Example: What You Should See

**In pgAdmin Query Tool:**
```
id | description | amount  | category      | date       | created_at
---+-------------+---------+---------------+------------+-------------------
1  | Groceries   | 1500.00 | Food          | 2024-01-15 | 2024-01-15 10:30:00
2  | Uber Ride   | 250.00  | Transport     | 2024-01-16 | 2024-01-16 14:20:00
```

**In Browser API:**
```json
[
  {
    "id": 1,
    "description": "Groceries",
    "amount": "1500.00",
    "category": "Food",
    "date": "2024-01-15"
  },
  {
    "id": 2,
    "description": "Uber Ride",
    "amount": "250.00",
    "category": "Transport",
    "date": "2024-01-16"
  }
]
```

---

**Use Method 1 (pgAdmin) for easiest visual check!** 🎯

