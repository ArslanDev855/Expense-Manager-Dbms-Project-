# 🌐 How to Run the Frontend

## ⚠️ IMPORTANT: Start Backend First!

**Before opening the frontend, make sure your backend server is running:**

1. Open terminal in the project folder
2. Run: `npm start`
3. You should see: `🚀 Server running on http://localhost:3000`

---

## Method 1: Open Directly (Easiest) ✅

1. **Make sure backend is running** (see above)
2. **Double-click** `index.html` file
3. It will open in your default browser
4. Done! 🎉

---

## Method 2: VS Code Live Server (Recommended) ⭐

1. Install **Live Server** extension in VS Code
   - Open VS Code
   - Go to Extensions (Ctrl+Shift+X)
   - Search "Live Server"
   - Click Install

2. **Right-click** on `index.html`
3. Select **"Open with Live Server"**
4. Browser opens automatically!

**Benefits:**
- Auto-refresh when you save changes
- Proper local server (no CORS issues)
- Better development experience

---

## Method 3: Python HTTP Server

If you have Python installed:

1. Open terminal in project folder
2. Run:
   ```bash
   # Python 3
   python -m http.server 8000
   
   # Or Python 2
   python -m SimpleHTTPServer 8000
   ```
3. Open browser: `http://localhost:8000`

---

## Method 4: Node.js http-server

1. Install globally: `npm install -g http-server`
2. Run: `http-server`
3. Open: `http://localhost:8080`

---

## ✅ Quick Checklist

- [ ] Backend server running (`npm start`)
- [ ] PostgreSQL database connected
- [ ] Frontend opened in browser
- [ ] Can see the Expense Manager interface

---

## 🐛 Troubleshooting

**Frontend shows errors?**
- Check if backend is running on port 3000
- Open browser console (F12) to see errors
- Make sure all files are in the same folder

**Can't connect to backend?**
- Verify backend is running: `http://localhost:3000/api/health`
- Check `script.js` has correct API_URL

**Page looks broken?**
- Make sure `styles.css` is in the same folder
- Make sure `script.js` is in the same folder

---

**That's it! Your frontend should be running now! 🚀**

