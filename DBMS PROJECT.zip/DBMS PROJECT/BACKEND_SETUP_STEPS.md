# 🔌 Step-by-Step: Connect Frontend to Backend

Follow these steps **IN ORDER**:

---

## ✅ STEP 1: Install PostgreSQL (If Not Already Installed)

1. Download PostgreSQL from: https://www.postgresql.org/download/windows/
2. Install it (remember your password during installation!)
3. Make sure PostgreSQL service is running

**Check if running:**
- Press `Win + R`
- Type `services.msc`
- Look for "postgresql" service - should be "Running"

---

## ✅ STEP 2: Create PostgreSQL Database

### Option A: Using pgAdmin (GUI - Easier)

1. Open **pgAdmin** (comes with PostgreSQL)
2. Connect to your PostgreSQL server (enter password)
3. Right-click on **"Databases"** → **"Create"** → **"Database..."**
4. Name: `expense_manager`
5. Click **"Save"**

### Option B: Using Command Line (psql)

1. Open PowerShell
2. Run:
```bash
psql -U postgres
```
3. Enter your PostgreSQL password
4. Run:
```sql
CREATE DATABASE expense_manager;
```
5. Type `\q` to exit

---

## ✅ STEP 3: Create Database Table

### Option A: Using pgAdmin

1. In pgAdmin, right-click on `expense_manager` database
2. Click **"Query Tool"**
3. Open `database.sql` file and copy ALL its contents
4. Paste into Query Tool
5. Click **"Execute"** (or press F5)

### Option B: Using Command Line

1. Open PowerShell in your project folder (`C:\Users\USER\Downloads\rr`)
2. Run:
```bash
psql -U postgres -d expense_manager -f database.sql
```
3. Enter your password when asked

---

## ✅ STEP 4: Create .env File (IMPORTANT!)

1. In your project folder (`C:\Users\USER\Downloads\rr`), create a new file named `.env`
   - **Important:** The file name is exactly `.env` (starts with a dot, no extension)

2. Open `.env` file and add this content:

```env
DB_USER=postgres
DB_HOST=localhost
DB_NAME=expense_manager
DB_PASSWORD=YOUR_POSTGRES_PASSWORD_HERE
DB_PORT=5432
PORT=3000
```

3. **Replace `YOUR_POSTGRES_PASSWORD_HERE`** with your actual PostgreSQL password!

**Example:**
```env
DB_USER=postgres
DB_HOST=localhost
DB_NAME=expense_manager
DB_PASSWORD=mypassword123
DB_PORT=5432
PORT=3000
```

---

## ✅ STEP 5: Install Node.js Packages

1. Open PowerShell in your project folder (`C:\Users\USER\Downloads\rr`)
2. Run this command:
```bash
npm install
```

**Wait for it to finish** - you should see packages being installed.

**Expected output:**
```
added 50 packages in 2 minutes
```

---

## ✅ STEP 6: Start the Backend Server

1. In the same PowerShell window, run:
```bash
npm start
```

2. **You should see:**
```
✅ Connected to PostgreSQL database
✅ Database table initialized
🚀 Server running on http://localhost:3000
📊 API endpoints available at http://localhost:3000/api
```

3. **Keep this window open!** The server must keep running.

---

## ✅ STEP 7: Test Backend Connection

1. Open your web browser
2. Go to: `http://localhost:3000/api/health`
3. You should see:
```json
{"status":"OK","database":"Connected"}
```

**If you see this, backend is connected! ✅**

---

## ✅ STEP 8: Open Frontend

1. **Keep backend running** (don't close the PowerShell window)
2. Open `index.html` in your browser
   - Double-click the file, OR
   - Right-click → Open with → Browser

3. The frontend will automatically connect to the backend!

---

## 🎉 DONE! Everything Should Work Now!

Try adding an expense:
1. Fill in the form
2. Click "Add Expense"
3. It should save to PostgreSQL database!

---

## 🐛 Troubleshooting

### Error: "Cannot find module 'express'"
**Solution:** Run `npm install` again

### Error: "password authentication failed"
**Solution:** Check your `.env` file - password is wrong

### Error: "database does not exist"
**Solution:** Create the database (Step 2)

### Error: "port 3000 already in use"
**Solution:** Change `PORT=3000` to `PORT=3001` in `.env` file, and update `script.js` line 1 to use port 3001

### Backend starts but shows database error
**Solution:** 
- Check PostgreSQL is running
- Check `.env` file has correct password
- Check database `expense_manager` exists

---

## 📝 Quick Checklist

- [ ] PostgreSQL installed and running
- [ ] Database `expense_manager` created
- [ ] Table created (ran database.sql)
- [ ] `.env` file created with correct password
- [ ] `npm install` completed
- [ ] Backend server running (`npm start`)
- [ ] Health check works (`http://localhost:3000/api/health`)
- [ ] Frontend opened in browser

---

**Need help? Check the error message and match it to the troubleshooting section above!**

