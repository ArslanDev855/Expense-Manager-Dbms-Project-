# 🚀 How to Run Frontend and Backend - Step by Step

## 📋 Quick Summary
1. **Start Backend** (Terminal 1)
2. **Open Frontend** (Browser)

---

## ✅ STEP-BY-STEP INSTRUCTIONS

### 🔧 STEP 1: Open Terminal/PowerShell

**Option A: In VS Code**
- Press `Ctrl + ~` (or View → Terminal)
- Terminal opens at bottom

**Option B: Windows PowerShell**
- Press `Win + X`
- Click "Windows PowerShell"
- Navigate to project folder:
```bash
cd C:\Users\USER\Downloads\rr
```

---

### 🖥️ STEP 2: Start Backend Server

**In the terminal, type:**
```bash
npm start
```

**Press Enter**

**✅ You should see:**
```
✅ Connected to PostgreSQL database
✅ Database table initialized
🚀 Server running on http://localhost:3000
📊 API endpoints available at http://localhost:3000/api
```

**⚠️ IMPORTANT:** 
- **Keep this terminal window OPEN!**
- The backend must keep running
- Don't close this window

---

### 🌐 STEP 3: Open Frontend

**Option A: Double-click method (Easiest)**
1. Go to File Explorer
2. Navigate to: `C:\Users\USER\Downloads\rr`
3. **Double-click** `index.html`
4. It opens in your default browser

**Option B: Right-click method**
1. Right-click on `index.html`
2. Select **"Open with"**
3. Choose your browser (Chrome, Edge, Firefox, etc.)

**Option C: VS Code Live Server (Best for development)**
1. Install "Live Server" extension in VS Code
2. Right-click `index.html`
3. Click **"Open with Live Server"**
4. Browser opens automatically

---

### ✅ STEP 4: Verify Everything Works

**Check Backend:**
- Open browser
- Go to: `http://localhost:3000/api/health`
- Should show: `{"status":"OK","database":"Connected"}`

**Check Frontend:**
- You should see the Expense Manager page
- Try adding an expense:
  1. Fill in description, amount, category, date
  2. Click "Add Expense"
  3. It should appear in the list below!

---

## 🎉 DONE! Your App is Running!

**What you should see:**
- ✅ Terminal showing backend is running
- ✅ Browser showing Expense Manager interface
- ✅ Can add expenses successfully

---

## 📝 Visual Guide

```
┌─────────────────────────────────────┐
│   TERMINAL (Backend Running)       │
│   npm start                         │
│   ✅ Server running on :3000       │
│                                     │
│   [Keep this open!]                │
└─────────────────────────────────────┘
              ↓
         API Connection
              ↓
┌─────────────────────────────────────┐
│   BROWSER (Frontend)                │
│   Expense Manager                   │
│   - Add Expense Form                │
│   - Expense List                    │
│                                     │
│   [Your app is here!]              │
└─────────────────────────────────────┘
```

---

## 🛑 How to Stop

**To stop backend:**
- Go to terminal window
- Press `Ctrl + C`
- Type `Y` if asked

**To stop frontend:**
- Just close the browser tab

---

## 🔄 Running Again Next Time

**Every time you want to use the app:**

1. **Open terminal** in project folder
2. **Run:** `npm start`
3. **Open:** `index.html` in browser
4. **Done!**

---

## ⚠️ Common Mistakes

❌ **Closing terminal while using app**
- ✅ Keep terminal open!

❌ **Starting backend twice**
- ✅ Check if port 3000 is already in use
- ✅ Close previous terminal first

❌ **Opening frontend before backend**
- ✅ Always start backend first!

---

## 🆘 Troubleshooting

**Backend won't start?**
- Check `.env` file has correct password
- Make sure PostgreSQL is running
- Check if port 3000 is free

**Frontend shows errors?**
- Make sure backend is running
- Check browser console (F12)
- Verify `script.js` has correct API_URL

**Can't add expenses?**
- Check backend terminal for errors
- Verify database connection
- Check browser console (F12)

---

**That's it! Follow these steps and your app will work perfectly! 🎉**

